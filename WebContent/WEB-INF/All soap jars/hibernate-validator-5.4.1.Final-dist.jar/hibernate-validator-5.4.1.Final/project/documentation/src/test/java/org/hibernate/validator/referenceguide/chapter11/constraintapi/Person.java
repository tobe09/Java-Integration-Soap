package org.hibernate.validator.referenceguide.chapter11.constraintapi;

public class Person {

	private String name;
}
