package org.hibernate.validator.referenceguide.chapter07;

public class Customer {
}
