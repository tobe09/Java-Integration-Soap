package org.hibernate.validator.referenceguide.chapter11.constraintapi;

public interface CarChecks {
}
