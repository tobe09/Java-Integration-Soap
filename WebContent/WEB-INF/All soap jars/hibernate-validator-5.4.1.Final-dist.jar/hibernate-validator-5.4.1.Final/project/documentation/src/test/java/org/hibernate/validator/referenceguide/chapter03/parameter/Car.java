package org.hibernate.validator.referenceguide.chapter03.parameter;

public class Car {
}
